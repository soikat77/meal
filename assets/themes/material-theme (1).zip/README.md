
# Material Theme Builder Flutter Export

## Basics

This archive contains a number of files defining a Material 3 theme:

 * colors_schemes.g.dart        - contains all colors used by your theme
 * main.g.dart                  - sample MyApp file using the generated color scheme

Your colors and schemes will be generated in a color_schemes.g.dart file to avoid collision
with other files that may exist in your project. A template My App file has been included for 
your convenience. You will need to replace the home with your content.


